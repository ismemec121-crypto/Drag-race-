# The-Big-Drag-Simulator
Relaunched Drag Simulator modded from https://myrainboww.github.io/Drag-Race-Simulator/index.html 
You can tip the owner of the original simulator in my sim!!

Current Update: Philippines Season 2 Cast + Updated Roast Challenge + Lipsync Challenge In Choose Challenges Mode

Next Update: TBD 
